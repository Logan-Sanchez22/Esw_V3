<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="summer forest, tree wall (canopy only)" tilewidth="128" tileheight="128" tilecount="24" columns="6">
 <image source="../summer tree wall/summer forest, tree wall (canopy only) 128x128.png" width="768" height="512"/>
</tileset>
